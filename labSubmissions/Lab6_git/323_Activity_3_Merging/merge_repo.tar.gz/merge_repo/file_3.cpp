#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

typedef int64_t ll;

int main(){

    ll T;
    cin>>T;

    for(ll I=1;I<=T;I++){

        vector<ll> a;
        ll n1;
        cin>>n1;
        a.resize(n1);
        for(ll j=0;j<n1;j++){

            cin>>a[j];
        }

        sort(a.begin(),a.end(),greater<>());

        cout<<"[ ";
        for(ll i=0;i<a.size();i++){
            
            cout<<a[i];

            if(i+1!=a.size()){

                cout<<", ";
            }
        }
        cout<<" ]\n";

        //From the development branch

        set<ll> b;
        ll n2;
        cin>>n2;
        
        for(ll j=0;j<n2;j++){

            ll x;
            cin>>x;
            b.insert(x);
        }

        cout<<"{ ";

        for(auto it=b.begin();it!=b.end();it++){
        
            cout<<*it;

            if(it!=prev(b.end())){

                cout<<" | ";
            }
        }
        cout<<" }\n";
    }
}