#include <iostream>

using namespace std;

float b1(int p1, float p2, float p3){

    return p2 + p3 - p1;
}

int b2(float p1){

    return b1(p1,p1,p1)+24;
}

int main(){

    int a,b,c;
    cin>>a>>b>>c;

    cout<<b1(b,a,c)-b2(c)<<"\n";
    
    cout<<"Hello File2\n";
}