#include <iostream>
#include "dfs.cpp"
#include "binary_search.cpp"
#include "bfs.cpp"
#include "matrixmul.cpp"
#include "sieve.cpp"

using namespace std;

int main(){

    vector<vector<int>> edges(7);

    edges[1].push_back(4);
    edges[1].push_back(2);
    edges[1].push_back(0);
    edges[2].push_back(3);
    edges[4].push_back(5);
    edges[5].push_back(6);

    vector<int> order = dfs(edges);

    for(auto x:order){

        cout<<x<<" ";
    }
    cout<<"\n";

    order = bfs(edges);

    for(auto x:order){

        cout<<x<<" ";
    }
    cout<<"\n";

    vector<int> array;

    array.push_back(0);
    array.push_back(2);
    array.push_back(3);
    array.push_back(7);
    array.push_back(11);
    array.push_back(15);
    array.push_back(17);

    for(int i=-1;i<=17;i++){

        cout<<i<<" : "<<binary_search(array,i)<<"\n";
    }

    vector<vector<int>> mat1(2,vector<int>(3,5));

    vector<vector<int>> mat2(3,vector<int>(2,4));

    vector<vector<int>> mat3=matrixmul(mat1,mat2);

    cout<<mat3[0][0]<<"\n";

    order=sieve(100);

    for(auto x:order){

        cout<<x<<" ";
    }
    cout<<"\n";
}